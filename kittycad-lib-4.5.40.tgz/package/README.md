# KittyCAD JS/TS API library

Fully typed js library, compatible with js and ts.

**Please see [CONTRIBUTING.md](./CONTRIBUTING.md) for how to to publish AND
AN EXPLANATION BEHIND THE DERIVATION PROCESS!**

### [Full documentation here](https://zoo.dev/docs/api?lang=typescript)

### Install

```bash
npm install @kittycad/lib
# or
yarn add @kittycad/lib

## set your token
export ZOO_API_TOKEN=<your token>
```

### Local development

To get started and check that all of the tests pass locally you must `npm install` and `npm run build` otherwise the tests will not pass. 

```
npm install
npm run build
npm run test
```

### Basic example
```typescript
import { Client, file } from '@kittycad/lib';
import fsp from 'fs/promises';

async function main() {
    const client = new Client()
    // zoo.dev/docs/api/get-cad-file-mass?lang=typescript
    const response = await file.create_file_mass({
      client,
      src_format: 'obj',
      material_density_unit: 'kg:m3',
      output_unit: 'g',
      material_density: 0.007,
      body: await fsp.readFile('./example.obj', 'base64'),
    })
    if ('error_code' in response) throw 'error'

    const { status, mass } = response
    console.log(status, mass);
}

main();
```
